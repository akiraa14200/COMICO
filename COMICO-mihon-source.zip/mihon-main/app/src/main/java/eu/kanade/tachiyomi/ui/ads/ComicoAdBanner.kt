package eu.kanade.tachiyomi.ui.ads

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp

private const val AD_SCRIPT = "https://pl30936971.profitableratecpmnetwork.com/56/bd/43/56bd4380fb862e2b0d27ea6b47964792.js"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ComicoAdBanner(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp),
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(AndroidColor.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.mediaPlaybackRequiresUserGesture = true
                webViewClient = WebViewClient()
                loadDataWithBaseURL(
                    "https://profitableratecpmnetwork.com/",
                    """
                    <!doctype html>
                    <html><head>
                    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
                    <style>html,body{margin:0;padding:0;background:transparent;overflow:hidden}</style>
                    </head><body>
                    <script src=\"$AD_SCRIPT\"></script>
                    </body></html>
                    """.trimIndent(),
                    "text/html",
                    "UTF-8",
                    null,
                )
            }
        },
        update = { it.visibility = android.view.View.VISIBLE },
    )
}
